package hr.fer.zemris.optjava.dz8.NeuralNetwork.Functions;

public interface ITransferFunction {
    double solveForInput(double entry);
}
