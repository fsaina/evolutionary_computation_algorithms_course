package hr.fer.zemris.optjava.dz8.Algorithm.Differentation.BaseVector;

import hr.fer.zemris.optjava.dz8.Algorithm.Unit;

import java.util.List;

public interface DEABaseVectorFunction {
    Unit apply(List<Unit> population);
}
