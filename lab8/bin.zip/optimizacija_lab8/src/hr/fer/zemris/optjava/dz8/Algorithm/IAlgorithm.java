package hr.fer.zemris.optjava.dz8.Algorithm;

public interface IAlgorithm {
    public void run();
}
